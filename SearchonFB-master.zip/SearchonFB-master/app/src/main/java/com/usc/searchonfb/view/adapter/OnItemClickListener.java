package com.usc.searchonfb.view.adapter;


import com.usc.searchonfb.rest.model.SearchModel.SearchData;

/**
 * Created by adarsh on 4/4/2017.
 */

public interface OnItemClickListener {
    void onItemClick(int itemCount);
}
